function FoodList(){
    return (
        <h1 className={"text-center"}>맛집 목록</h1>
    )
}

export default FoodList