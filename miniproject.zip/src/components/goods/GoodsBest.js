function GoodsBest(){
    return (
        <h1 className={"text-center"}>베스트 상품</h1>
    )
}

export default GoodsBest