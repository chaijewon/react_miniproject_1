function GoodsSpecial(){
    return (
        <h1 className={"text-center"}>특가 상품</h1>
    )
}
export default GoodsSpecial