function GoodsNew(){
    return (
        <h1 className={"text-center"}>신상품</h1>
    )
}
export default GoodsNew